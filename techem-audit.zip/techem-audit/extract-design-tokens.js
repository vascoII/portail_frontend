// extract-design-tokens.js
// Audit des couleurs & polices d'un site et génération d'un design-tokens.json
// Usage: node extract-design-tokens.js https://www.techem.com/corp/en

import fs from 'fs';
import puppeteer from 'puppeteer';

/** --------- Utilitaires couleurs --------- **/

function clamp255(n) { return Math.max(0, Math.min(255, Math.round(n))); }
function toHex(n) { return clamp255(n).toString(16).padStart(2, '0').toUpperCase(); }

function rgbToHex(str) {
  const m = str.match(/rgba?\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)(?:\s*,\s*([\d.]+))?\s*\)/i);
  if (!m) return null;
  const [_, r, g, b, a] = m;
  if (a !== undefined && parseFloat(a) === 0) return null; // transparent
  return `#${toHex(parseFloat(r))}${toHex(parseFloat(g))}${toHex(parseFloat(b))}`;
}

function hslToHex(str) {
  const m = str.match(/hsla?\(\s*([\d.]+)\s*,\s*([\d.]+)%\s*,\s*([\d.]+)%(?:\s*,\s*([\d.]+))?\s*\)/i);
  if (!m) return null;
  const [_, H, S, L, A] = m;
  if (A !== undefined && parseFloat(A) === 0) return null;
  let h = parseFloat(H) / 360;
  let s = parseFloat(S) / 100;
  let l = parseFloat(L) / 100;

  const hue2rgb = (p, q, t) => {
    if (t < 0) t += 1;
    if (t > 1) t -= 1;
    if (t < 1/6) return p + (q - p) * 6 * t;
    if (t < 1/2) return q;
    if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
    return p;
  };

  const q = l < 0.5 ? l * (1 + s) : (l + s - l * s);
  const p = 2 * l - q;
  const r = hue2rgb(p, q, h + 1/3);
  const g = hue2rgb(p, q, h);
  const b = hue2rgb(p, q, h - 1/3);

  return `#${toHex(r * 255)}${toHex(g * 255)}${toHex(b * 255)}`;
}

function normalizeColorToHex(value) {
  if (!value) return null;
  const c = value.trim().toLowerCase();
  if (c === 'transparent') return null;
  if (c.startsWith('#')) {
    // #abc → #aabbcc
    if (c.length === 4) {
      const r = c[1], g = c[2], b = c[3];
      return `#${r}${r}${g}${g}${b}${b}`.toUpperCase();
    }
    return c.toUpperCase();
  }
  if (c.startsWith('rgb')) return rgbToHex(c);
  if (c.startsWith('hsl')) return hslToHex(c);
  // Noms CSS (e.g., 'white')—on laisse tel quel, ou convertit via une map si nécessaire
  return c; // fallback (rare)
}

/** --------- Utilitaires fonts --------- **/

function normalizeFontFamily(family) {
  if (!family) return null;
  // prend la première famille déclarée et retire les quotes
  const first = family.split(',')[0].trim().replace(/^["']|["']$/g, '');
  // ignore les familles génériques si seules
  if (['serif', 'sans-serif', 'monospace', 'cursive', 'fantasy', 'system-ui'].includes(first.toLowerCase())) {
    return null;
  }
  return first;
}

/** --------- Parsing CSS côté Node --------- **/

function extractCssVariables(cssTexts) {
  const vars = {};
  for (const css of cssTexts) {
    const rootBlocks = css.match(/:root\s*\{[^}]*\}/g) || [];
    for (const block of rootBlocks) {
      const decls = block.slice(block.indexOf('{') + 1, block.lastIndexOf('}'));
      const matches = decls.match(/--[\w-]+\s*:\s*[^;]+/g) || [];
      for (const m of matches) {
        let [name, value] = m.split(':');
        name = name.trim();
        value = value.trim();
        const hex = normalizeColorToHex(value);
        vars[name] = hex || value;
      }
    }
  }
  return vars;
}

function extractFontFaces(cssTexts) {
  const faces = [];
  for (const css of cssTexts) {
    const blocks = css.match(/@font-face\s*\{[^}]*\}/g) || [];
    for (const block of blocks) {
      const fam = block.match(/font-family\s*:\s*([^;]+);/i);
      const src = block.match(/src\s*:\s*([^;]+);/i);
      const wgt = block.match(/font-weight\s*:\s*([^;]+);/i);
      const sty = block.match(/font-style\s*:\s*([^;]+);/i);
      faces.push({
        fontFamily: fam ? fam[1].trim().replace(/^["']|["']$/g, '') : undefined,
        src: src ? src[1].trim() : undefined,
        fontWeight: wgt ? wgt[1].trim() : undefined,
        fontStyle: sty ? sty[1].trim() : undefined,
      });
    }
  }
  return faces;
}

/** --------- Scroll pour charger le lazy content --------- **/
async function autoScroll(page) {
  await page.evaluate(async () => {
    await new Promise((resolve) => {
      let totalHeight = 0;
      const distance = 600;
      const timer = setInterval(() => {
        const scrollHeight = document.body.scrollHeight;
        window.scrollBy(0, distance);
        totalHeight += distance;
        if (totalHeight >= scrollHeight - window.innerHeight) {
          clearInterval(timer);
          resolve();
        }
      }, 300);
    });
  });
}

/** --------- Main --------- **/

(async () => {
  const url = process.argv[2] || 'https://www.techem.com/corp/en';
  const browser = await puppeteer.launch({ headless: 'new', defaultViewport: { width: 1440, height: 900 } });
  const page = await browser.newPage();

  const cssTexts = [];
  const fontUrls = new Set();

  // Capture des CSS et des fonts via les réponses réseau (contourne CORS)
  page.on('response', async (response) => {
    const ct = (response.headers()['content-type'] || '').toLowerCase();
    const url = response.url();
    try {
      if (ct.includes('text/css') || url.match(/\.css(\?|$)/)) {
        const text = await response.text();
        cssTexts.push(text);
      }
      if (ct.includes('font') || url.match(/\.(woff2?|ttf|otf)(\?|$)/)) {
        fontUrls.add(url);
      }
    } catch (_) {
      // certaines réponses ne sont pas lisibles, on ignore
    }
  });

  await page.goto(url, { waitUntil: 'networkidle0' });
  await autoScroll(page);
  await page.waitForTimeout(800);

  // Évaluation côté page pour récupérer les styles EFFECTIVEMENT rendus
  const result = await page.evaluate(() => {
    const colorSet = new Set();
    const fontSet = new Set();

    function pushColor(c) {
      if (!c) return;
      const s = c.trim().toLowerCase();
      if (s === 'transparent') return;
      if (s.startsWith('rgba')) {
        const m = s.match(/rgba\(\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*,\s*([\d.]+)\s*\)/);
        if (m && parseFloat(m[4]) === 0) return;
      }
      colorSet.add(s);
    }

    const all = Array.from(document.querySelectorAll('*'));
    all.forEach((el) => {
      const cs = getComputedStyle(el);
      pushColor(cs.color);
      pushColor(cs.backgroundColor);
      ['Top', 'Right', 'Bottom', 'Left'].forEach((side) => {
        pushColor(cs[`border${side}Color`]);
      });
      fontSet.add(cs.fontFamily);
    });

    const bodyFont = getComputedStyle(document.body).fontFamily;
    const h1 = document.querySelector('h1');
    const headingFont = h1 ? getComputedStyle(h1).fontFamily : bodyFont;

    return {
      rawColors: Array.from(colorSet),
      rawFonts: Array.from(fontSet),
      bodyFont,
      headingFont,
    };
  });

  // Normalisation couleurs (→ hex si possible)
  const hexColors = new Set();
  for (const c of result.rawColors) {
    const hex = normalizeColorToHex(c);
    if (hex) hexColors.add(hex);
  }

  // Normalisation familles de polices
  const families = new Set();
  for (const f of result.rawFonts) {
    const n = normalizeFontFamily(f);
    if (n) families.add(n);
  }
  const bodyFamily = normalizeFontFamily(result.bodyFont) || null;
  const headingFamily = normalizeFontFamily(result.headingFont) || bodyFamily || null;

  // Extraction CSS variables & @font-face depuis les CSS capturées
  const cssVariables = extractCssVariables(cssTexts);
  const fontFaces = extractFontFaces(cssTexts);

  const tokens = {
    source: url,
    generatedAt: new Date().toISOString(),
    colors: {
      hex: Array.from(hexColors).sort(),       // palette brute appliquée
      cssVariables,                            // variables :root si présentes
    },
    fonts: {
      families: Array.from(families).sort(),
      body: bodyFamily,
      heading: headingFamily,
      fontFiles: Array.from(fontUrls).sort(),  // utile pour audit licence
      fontFaces,                               // métadonnées des @font-face
    },
  };

  fs.writeFileSync('design-tokens.json', JSON.stringify(tokens, null, 2), 'utf-8');
  console.log('✅ design-tokens.json généré.');
  await browser.close();
})();


